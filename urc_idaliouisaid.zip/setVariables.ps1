# SetEnvVariables.ps1

# Specify the path to your .env.development.local file
$envFilePath = ".env.development.local"

# Read the content of the file and set environment variables
Get-Content $envFilePath | ForEach-Object {
    # Skip lines that are comments or empty
    if (-not ($_ -match '^\s*#') -and $_.Trim() -ne '') {
        # Split the line into variable and value
        $variable, $value = $_ -split '=', 2

        # Remove leading and trailing spaces from the value
        $value = $value.Trim()

        # Set the environment variable
        [System.Environment]::SetEnvironmentVariable($variable, $value, [System.EnvironmentVariableTarget]::Process)
    }
}

# Display the updated environment variables
Get-ChildItem env:
